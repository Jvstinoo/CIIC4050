#ifndef PRINT_ARRAY_H
#define PRINT_ARRAY_H

void PrintArray(void* array, int type);

#endif  // PRINT_ARRAY_H