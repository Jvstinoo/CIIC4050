#ifndef EXPLORE_DIRECTORY_H
#define EXPLORE_DIRECTORY_H

void ExploreDirectory(const char *dirpath, const char *word);

#endif  // EXPLORE_DIRECTORY_H